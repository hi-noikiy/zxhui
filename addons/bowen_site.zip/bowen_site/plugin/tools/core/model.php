<?php
/**
 * 玖祺企业官网
 *
 * @author Bowen
 * @url www.we7pc.com
 * <!-- phpDesigner :: Timestamp [2018/8/18 22:43:01] -->
 */
defined('IN_IA') or exit('Access Denied');

class ToolsModel extends PluginModel
{
    
}
