<?php
/**
 * 玖祺企业官网
 *
 * @author Bowen
 * @url www.we7pc.com
 * <!-- phpDesigner :: Timestamp [2018/8/18 17:31:38] -->
 */
defined('IN_IA') or exit('Access Denied');

!(defined('REDIRECT_URI')) && define('REDIRECT_URI', 'addons/bowen_site/plugin/pcsite/auth2.php');