<?php
/**
 * 企业官网
 *
 * @author Bowen
 * @url www.we7pc.com
 * <!-- phpDesigner :: Timestamp [2018/11/18 17:58:25] -->
 */
defined('IN_IA') or exit('Access Denied');

class Perm_ComModel extends ComModel
{

}